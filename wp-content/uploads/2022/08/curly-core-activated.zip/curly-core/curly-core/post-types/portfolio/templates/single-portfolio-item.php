<?php

get_header();

curly_mkdf_get_title();

do_action('curly_mkdf_before_main_content');

curly_core_get_single_portfolio();

get_footer();