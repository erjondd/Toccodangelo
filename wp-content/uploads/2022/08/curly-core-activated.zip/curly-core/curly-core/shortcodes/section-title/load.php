<?php

include_once CURLY_CORE_SHORTCODES_PATH . '/section-title/functions.php';
include_once CURLY_CORE_SHORTCODES_PATH . '/section-title/section-title.php';