<?php


define('CURLY_TWITTER_FEED_VERSION', '2.0.2');
define('CURLY_TWITTER_ABS_PATH', dirname(__FILE__));
define('CURLY_TWITTER_REL_PATH', dirname(plugin_basename(__FILE__)));
define('CURLY_TWITTER_URL_PATH', plugin_dir_url(__FILE__));
define('CURLY_TWITTER_ASSETS_PATH', CURLY_TWITTER_ABS_PATH . '/assets');
define('CURLY_TWITTER_ASSETS_URL_PATH', CURLY_TWITTER_URL_PATH . 'assets');
define('CURLY_TWITTER_SHORTCODES_PATH', CURLY_TWITTER_ABS_PATH . '/shortcodes');
define('CURLY_TWITTER_SHORTCODES_URL_PATH', CURLY_TWITTER_URL_PATH . 'shortcodes');